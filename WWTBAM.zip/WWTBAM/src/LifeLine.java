
public abstract class LifeLine {
    public abstract boolean isUsed();
    public abstract void use();
    public abstract void resetUses();
}
